BA-2 (Blast All Bot Mark 2)
By: Quandtum
License: CC-0
Blender Version: 2.66a, r55057
Model Version: 1.1

3D preview available @ http://p3d.in/i67jh

What is included:
1 x BA-2 base mesh (3380 vertices, 6964 Edges, 3616 faces, 6696 Tris, UV unwrapped)
1 x Diffuse map (2048 x 2048)
1 x Normal map (2048 x 2048)
1 x Bump map (2048 x 2048)
1 x Specular map (2048 x 2048)
1 x Emission map (2048 x 2048)
1 x Animation armature

Complete model is not manifold, but rather a composition of manifold "parts".  Each part is manifold and all parts were combined into a single mesh named "Bot.Mesh".

Maps included are all large 2048 x 2048.  Reason is they can be reduced but not grown, resize them to fit as needed.

Texture samples sourced from:
http://www.plaintextures.com/
http://www.goodtextures.com/
Textures were otherwise hand painted.

There is admittingly an error in the bump/normal mapping in the emission areas.  They are not very noticable, and with the emission map enabled they are concealed.

Revision History:
    Version 1.0 - 01/21/2013; Initial release.
    Version 1.1 - Sat Mar 23 14:36:46 CDT 2013; Updated branding.
