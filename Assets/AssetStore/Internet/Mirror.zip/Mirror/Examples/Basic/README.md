# Basic example

Show how to set up a NetworkManager, players and connect a server to a client

1) Open the scene in unity
2) File -> Build and run   as standalone 
3) When the standalone starts,  click on Host
4) the standalone starts as both a client and a server and starts listening to port 7777
5) From the editor click play
6) Click connect
7) Now you will see both players in both the standalone and client,  and their data will be synchornized
