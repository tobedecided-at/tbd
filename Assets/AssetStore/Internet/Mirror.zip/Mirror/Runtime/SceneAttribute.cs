﻿using UnityEngine;

namespace Mirror
{
    // For Scene property Drawer
    public class SceneAttribute : PropertyAttribute
    {
    }
}