Mirror is a MMO Scale Networking library for Unity, used in uMMORPG, uSurvival
and several MMO projects in development.

  https://github.com/vis2k/Mirror

Documentation:
  https://vis2k.github.io/Mirror/

Support:
  Discord: https://discordapp.com/invite/N9QVxbM
  Bug Reports: https://github.com/vis2k/Mirror/issues
